package com.ItsLZ.ui;

public class StartGame {
    public StartGame(){
        // 从文件中读取数据
        RegisterJFrame.LoadFromFile();
        // 登录界面
        new LoginJFrame();
    }
}
