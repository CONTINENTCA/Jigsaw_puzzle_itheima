package com.ItsLZ.ui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.ArrayList;

public class RegisterJFrame extends JFrame implements ActionListener, MouseListener {
    // JFrame是个JavaBeam类 表示界面 窗体
    // 跟注册相关的逻辑写在这里
    static class User{
        public String Username;
        public String UserPassword;
        public User(String username, String userPassword) {
            this.Username = username;
            this.UserPassword = userPassword;
        }
    }
    static ArrayList<User> users = new ArrayList<>(); // 保存User类的ArrayList

    private final String path = "image\\register\\";
    JTextField UserNameTextField = new JTextField(); // 用户名输入框
    JPasswordField PasswordTextField = new JPasswordField(); // 密码输入框
    JPasswordField PasswordTextField2 = new JPasswordField(); // 确认密码输入框
    JButton ExitButton = new JButton("返回"); // 返回登录界面的按钮
    JButton RegisterButton = new JButton(); // 注册按钮
    JButton ResetButton = new JButton(); // 重置按钮

    public RegisterJFrame() {

        // 初始化注册界面
        initRegisterFrame();

        // 初始化注册界面的组件
        initView();

        // 显示界面
        this.setVisible(true);
    }

    private void initRegisterFrame(){
        // 设置界面宽高
        this.setSize(480, 430);
        // 居中界面
        this.setLocationRelativeTo(null);
        // 设置标题
        this.setTitle("注册界面");
        // 关闭窗口时退出程序
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // 取消默认布局
        this.setLayout(null);
        // 设置界面置顶
        this.setAlwaysOnTop(true);
    }

    private void initView(){

        // 用户名
        JLabel UserNameLabel = new JLabel(new ImageIcon(path + "RegisterUsername.png"));
        UserNameLabel.setBounds(-100, -60, getWidth(), getHeight());
        this.getContentPane().add(UserNameLabel);
        // 用户名输入
        // JTextField UserNameTextField = new JTextField();
        UserNameTextField.setBounds(200, 140, 200, 30);
        this.getContentPane().add(UserNameTextField);

        // 密码
        JLabel PasswordLabel = new JLabel(new ImageIcon(path + "RegisterPassword.png"));
        PasswordLabel.setBounds(-93, -10, getWidth(), getHeight());
        this.getContentPane().add(PasswordLabel);

        // 密码输入
        // JPasswordField PasswordTextField = new JPasswordField();
        PasswordTextField.setBounds(200, 190, 200, 30);
        this.getContentPane().add(PasswordTextField);

        // 确认密码
        JLabel PasswordLabel2 = new JLabel(new ImageIcon(path + "EnterAgain.png"));
        PasswordLabel2.setBounds(-108, 40, getWidth(), getHeight());
        this.getContentPane().add(PasswordLabel2);

        // 确认密码输入
        //JPasswordField PasswordTextField2 = new JPasswordField();
        PasswordTextField2.setBounds(200, 240, 200, 30);
        this.getContentPane().add(PasswordTextField2);

        // 注册按钮
        // JButton RegisterButton = new JButton();
        RegisterButton.setActionCommand("Register"); //和ActionListener中的e.getActionCommand().equal()有关
        RegisterButton.setIcon(new ImageIcon(path + "Register1.png")); // 相当于是给按钮的外观变成一个图片了
        RegisterButton.setBounds(100,305, 128, 47);
        RegisterButton.setBorderPainted(false); // 去除按钮的边框
        RegisterButton.setContentAreaFilled(false); // 去除按钮的背景
        // RegisterButton.setFocusPainted(false); // 去除按钮焦点边框
        RegisterButton.addActionListener(this);
        RegisterButton.addMouseListener(this);
        this.getContentPane().add(RegisterButton);

        // 重置按钮
        // JButton ResetButton = new JButton();
        ResetButton.setActionCommand("Reset"); //和ActionListener中的e.getActionCommand().equal()有关
        ResetButton.setIcon(new ImageIcon(path + "Reset1.png")); // 相当于是给按钮的外观变成一个图片了
        ResetButton.setBounds(260,305, 128, 47);
        ResetButton.setBorderPainted(false); // 去除按钮的边框
        ResetButton.setContentAreaFilled(false); // 去除按钮的背景
        ResetButton.addActionListener(this);
        ResetButton.addMouseListener(this);
        this.getContentPane().add(ResetButton);

        // 返回登陆界面
        //JButton ExitButton = new JButton("返回");
        ExitButton.setActionCommand("Exit"); //和ActionListener中的e.getActionCommand().equal()有关
        ExitButton.setBounds(12,25,59,30);
        ExitButton.addActionListener(this);
        this.getContentPane().add(ExitButton);

        // 设置背景图片
        JLabel BackGroundlabel = new JLabel(new ImageIcon(path + "background.png"));
        BackGroundlabel.setBounds(-9, -16, getWidth(), getHeight());
        this.getContentPane().add(BackGroundlabel);

    }

    // 保存到文件
    private void SaveToFile(String UserName, String UserPassword){
        File file = new File("./Users.txt");
        if(!file.exists()){
            try{
                file.createNewFile();
            }catch(Exception e){
                e.printStackTrace();
            }
        }
        try(FileOutputStream fos = new FileOutputStream(file,true)){ // 追加
            fos.write((UserName + " " + UserPassword + "\n").getBytes());
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    // 保存到文件（重载）
    private void SaveToFile(ArrayList<User> users){
        // 清空文件
        try{
            new FileWriter("./Users.txt").close();
        }catch(Exception e){
            e.printStackTrace();
        }

        for(User user : users){
            SaveToFile(user.Username, user.UserPassword);
        }
    }

    // 从文件中读取数据
    public static void LoadFromFile(){
        File file = new File("./Users.txt");
        if(!file.exists()){
            throw new RuntimeException("文件不存在");
        }

        // 空文件判断
        if (file.length() == 0) {
            return; // 文件为空直接返回
        }

        try(FileInputStream fis = new FileInputStream(file)){
            byte[] data = new byte[(int)file.length()];
            fis.read(data);
            String s = new String(data);
            String[] str = s.split("\n");
            for(String temp : str){
                String[] str2 = temp.split(" ");
                users.add(new User(str2[0], str2[1]));
                // System.out.println(str2[0] + " " + str2[1]); //调试
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private boolean JudgeEmpty() {
        if(UserNameTextField.getText().isEmpty() || new String(PasswordTextField.getPassword()).isEmpty()  //如果用户名或密码或再次输入密码其中一个为空 则返回
                || new String(PasswordTextField2.getPassword()).isEmpty()){
            LoginJFrame.ShowJDialog("请输入完整内容");
            return true;
        }
        if(!(new String(PasswordTextField.getPassword()).equals(new String(PasswordTextField2.getPassword())))){
            LoginJFrame.ShowJDialog("两次密码不一致");
            return true;
        }
        return false;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == ExitButton){
            this.setVisible(false);
            new LoginJFrame();
        }else if(e.getSource() == RegisterButton){ // 注册
            if (JudgeEmpty()) return;
            for(User user : users){  // 遍历arraylist 如果用户名或密码与arraylist中的用户名或密码相同 则返回
                if(user.Username.equals(UserNameTextField.getText())){
                    LoginJFrame.ShowJDialog("用户名已存在");
                    return;
                }
                if(user.UserPassword.equals(new String(PasswordTextField.getPassword()))){
                    LoginJFrame.ShowJDialog("密码已存在");
                    return;
                }
            }
            users.add(new User(UserNameTextField.getText(),new String(PasswordTextField.getPassword()))); // 在arraylist中添加用户名和密码
            SaveToFile(users.getLast().Username, users.getLast().UserPassword); // 保存到文件中
            LoginJFrame.ShowJDialog("注册成功");
        }else if(e.getSource() == ResetButton){ // 重置密码
            if (JudgeEmpty()) return;
            for(User user : users){  // 遍历arraylist 如果用户名与arraylist中的用户名相同 则跳出
                if(user.Username.equals(UserNameTextField.getText())){
                    user.UserPassword = new String(PasswordTextField.getPassword());
                    LoginJFrame.ShowJDialog("修改成功");
                    SaveToFile(users);
                    return;
                }
            }
            LoginJFrame.ShowJDialog("用户名不存在");
        }
    }


    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        if(e.getSource() == RegisterButton){
            RegisterButton.setIcon(new ImageIcon(path + "Register2.png"));
        }
        if(e.getSource() == ResetButton){
            ResetButton.setIcon(new ImageIcon(path + "Reset2.png"));
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == RegisterButton){
            RegisterButton.setIcon(new ImageIcon(path + "Register1.png"));
        }
        if(e.getSource() == ResetButton){
            ResetButton.setIcon(new ImageIcon(path + "Reset1.png"));
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
