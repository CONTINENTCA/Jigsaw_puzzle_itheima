package com.ItsLZ.ui;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import java.awt.event.*;
import java.util.Random;

// 前情提要：本游戏所有坐标轴统一如下
/*
-----------------------------------------→ X
|
|
|
|
|
|
|
|
|
↓
Y
 */
public class GameJFrame extends JFrame implements KeyListener, MouseListener,ActionListener {
    // JFrame是个JavaBeam类 表示界面 窗体
    // 规定：GameJFrame这个界面表示的是游戏主界面
    // 所有跟游戏相关的逻辑写在这个类

    // 创建随机数对象
    Random rand = new Random();

    // 二维数组作用:加载图片时 会根据二维数组内被打乱的0 - 15 随机数来加载
    private int[][] arr = new int[4][4];
    private int CurX = 3,CurY = 3; // 记录空白格的坐标;
    private int CurMouseX,CurMouseY; // 记录鼠标当前位置的坐标;
    private boolean AllImgButton = false; // 记录是否是显示完整图片的状态;

    // 记录当时展示图片的路径
    private String imgPath;

    // 存储正确的图片顺序
    int[][] Win = {
            {1,2,3,4},
            {5,6,7,8},
            {9,10,11,12},
            {13,14,15,0}
    };

    // 记录步数
    private int Step = 0;

    // 创建JMenuItem对象(本来是写在initJMenuBar()方法中的，但是这样写会导致重复代码，所以我把它提取出来了)
    JMenuItem Girl = new JMenuItem("美女");
    JMenuItem Animal = new JMenuItem("动物");
    JMenuItem Sport = new JMenuItem("运动");
    JMenuItem ReplayItem = new JMenuItem("重新游戏");
    JMenuItem ReLoginItem = new JMenuItem("重新登陆");
    JMenuItem CloseItem = new JMenuItem("关闭游戏");

    JMenuItem GameDeveloper = new JMenuItem("游戏作者");

    JMenuItem Buy = new JMenuItem("氪金入口");

    // 选择图片
    private final int GIRL = 0;
    private final int ANIMAL = 1;
    private final int SPORT = 2;

    public GameJFrame(){
        // 初始化窗口
        initGameJFrame();

        // 初始化JMenuBar
        initJMenuBar();

        // 初始化Data
        initData();

        // 随机获取图片
        SetImgPath(rand.nextInt(3));

        // 初始化图片
        initImg();

        // 加载窗口(建议写最后)
        this.setVisible(true);
    }

    // 1 初始化界面
    private void initGameJFrame(){

        // 设置界面的宽高
        this.setSize(604,680);
        // 居中界面
        this.setLocationRelativeTo(null);
        // 设置标题
        this.setTitle("拼图单机版 v1.0");
        // 设置界面置顶
        this.setAlwaysOnTop(true);
        // 当我们点击关闭按钮时，程序直接退出
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // 关闭窗口时退出程序 WindowConstants.EXIT_ON_CLOSE（也可以）
        /*
        DO_NOTHING_ON_CLOSE = 0 不做任何操作
        HIDE_ON_CLOSE = 1 隐藏窗口
        DISPOSE_ON_CLOSE = 2 释放窗口(你有多个窗口时，直到关闭最后一个窗口（所有界面都要做这个设置），关闭虚拟机)
        EXIT_ON_CLOSE = 3 退出程序
         */

        // 取消默认的居中放置！！！（只有这样才能按照x y轴的方式添加组件）
        this.setLayout(null);

        // 给整个窗口添加键盘监听器
        this.addKeyListener(this);

        // 给窗口添加MouseListener
        this.addMouseListener(this);

    }

    // 2 初始化JMenuBar
    private void initJMenuBar(){
        // 创建整个的菜单对象 JMenuBar 表示菜单条 JMenu表示菜单  JMenuItem表示菜单项
        JMenuBar jMenuBar = new JMenuBar();
        // jMenuBar.setBounds(0,0,603,25); // 可以设置菜单条的大小和位置（非常不建议）


        // 创建菜单上面（JMenu）的两个选项对象 （功能 关于我们 氪金等。。。）
        JMenu ChangeImg = new JMenu("更换图片");
        JMenu FunctionJMenu = new JMenu("功能");
        JMenu AboutJMenu = new JMenu("关于我们");
        JMenu BuyJMenu = new JMenu("氪金!!!");


        // 给JMenuItem添加监听器
        Girl.addActionListener(this); // 更换图片的JMenuItem
        Animal.addActionListener(this);
        Sport.addActionListener(this);
        ReplayItem.addActionListener(this);
        ReLoginItem.addActionListener(this);
        CloseItem.addActionListener(this);

        GameDeveloper.addActionListener(this);

        Buy.addActionListener(this);

        // 把JMenuItem加载到JMenu中
        ChangeImg.add(Girl);
        ChangeImg.add(Animal);
        ChangeImg.add(Sport);

        FunctionJMenu.add(ChangeImg); // ChangeImg是JMenu对象 也可以直接添加到FunctionJMenu（JMenu对象）中
        FunctionJMenu.add(ReplayItem);
        FunctionJMenu.add(ReLoginItem);
        FunctionJMenu.add(CloseItem);

        AboutJMenu.add(GameDeveloper);

        BuyJMenu.add(Buy);

        // 把JMenu加载到JMenuBar中
        jMenuBar.add(FunctionJMenu);
        jMenuBar.add(AboutJMenu);
        jMenuBar.add(BuyJMenu);

        // 把JMenuBar加载到GameJFrame中
        this.setJMenuBar(jMenuBar);
    }

    // 3 初始化数据
    private void initData(){

        // 生成16个0 - 15的随机数（每个数字都出现一次）
        int[] tempArr = new int[16];
        for(int i=0;i<tempArr.length;i++){
            tempArr[i] = i;
        }

        // 洗牌算法 打乱数组中的数字
        for(int i=tempArr.length - 1;i>=0;i--){
            int j = rand.nextInt(i + 1);
            int temp = tempArr[j];
            tempArr[j] = tempArr[i];
            tempArr[i] = temp;
        }

        // 这个for循环确保数组最后一个永远是0 （确保拼图的素材没有0.png 所以右下角总是 一角）
        for(int i=0;i<tempArr.length;i++){
            if(tempArr[i] == 15){
                boolean flag = false;
                for(int j = 0;j<tempArr.length;j++){
                    if(tempArr[j] == 0){
                        tempArr[j] = tempArr[tempArr.length - 1];
                        tempArr[tempArr.length - 1] = 0;
                        flag = true;
                        break;
                    }
                }
                if(flag){
                    break;
                }
            }
        }

        for(int i=0;i<16;i++){
            arr[i/4][i%4] = tempArr[i];
            //System.out.println(tempArr[i]);
        }
    }

    // 4 初始化图片
    private void initImg(){

        // 细节：先加载的图片 在上方 后加载的图片在后方！！！！

        // 先把界面上的图片都删除
        this.getContentPane().removeAll();

        // 判断游戏是否胜利
        if(IsWin()){
            ImageIcon WinImg = new ImageIcon("image\\win.png");
            JLabel WinImgLabel = new JLabel(WinImg);
            WinImgLabel.setBounds(0, 0, 604, 680);
            this.getContentPane().add(WinImgLabel);
        }

        // 加载步数
        JLabel StepLabel = new JLabel("步数:" + Step);
        StepLabel.setBounds(50, 30, 100, 20);
        this.getContentPane().add(StepLabel);


        // 创建图片ImageIcon对象
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                //if(i == 3 && j == 3) break;
                ImageIcon icon = new ImageIcon(imgPath + arr[j][i] + ".jpg");

                // 创建一个JLabel对象（管理容器）
                JLabel jLabel = new JLabel(icon);

                // 指定图片位置
                jLabel.setBounds(84 + i*105,   130 + j*105, icon.getIconWidth(), icon.getIconHeight());

                // 给图片增加边框
                jLabel.setBorder(new BevelBorder(BevelBorder.RAISED)); // 斜面边框（边框分为好多种 需要用时再查API文档）
                // BevelBorder.RAISED == 0  看起来让图片凸起来
                // BevelBorder.LOWERED == 1  看起来像让图片凹下去

                // 把管理容器添加到界面中
                //this.add(jLabel); // 也可以达到相同效果 但是不推荐
                this.getContentPane().add(jLabel); // 先获取窗口的内容窗格容器再使用add方法 比较明确 推荐使用这个
                /*
                getContentPane() 的作用
                定义：getContentPane() 是 JFrame 的方法，用于获取窗口的内容窗格容器
                本质：返回的是一个 Container 对象（通常是 JPanel 实例），它是窗口的主内容区域
                类比：想象一个相框
                框架本身 = JFrame（窗口边框和标题栏）
                内容窗格 = 相框里放照片的区域（实际显示内容的位置）
                 */

            }
        }

        // 创建背景图片
        ImageIcon backGround = new ImageIcon("image\\background.png");
        JLabel backGroundLabel = new JLabel(backGround);
        backGroundLabel.setBounds(39, 35, backGround.getIconWidth(), backGround.getIconHeight());
        this.getContentPane().add(backGroundLabel);

        // 创建按钮
        setButton();

        // 刷新界面
        this.getContentPane().repaint(); // 刷新界面 （如果不刷新界面 图片不会显示出来）

    }

    // 5 获取鼠标当前位置
    private void GetMousePosition(MouseEvent e){
        if(e.getButton() == MouseEvent.BUTTON1 && e.getX() >= 90 && e.getX() <= 510 && e.getY() >= 182 && e.getY() <= 602){
            CurMouseY = (e.getX() + 15) / 105 - 1;
            CurMouseX = (e.getY() - 77) / 105 - 1;
            // System.out.println("<UNK>"+CurMouseX+"<UNK>"+CurMouseY);
        }
    }

    // 6 设置按钮
    private void setButton(){
        // 创建显示完整图片的按钮
        JButton ShowAllImg = new JButton("完整图片");
        ShowAllImg.addActionListener(this);
        ShowAllImg.setBounds(440,15,100,40);
        ShowAllImg.setFocusable(false);  // 关键修复
        this.getContentPane().add(ShowAllImg);
    }

    // 7 判断游戏是否胜利
    private boolean IsWin(){
        for(int i=0;i<4;i++){
            for(int j=0;j<4;j++){
                if(arr[i][j] != Win[i][j]){
                    return false;
                }
            }
        }
        // System.out.println("Win");
        return true;
    }

    // 8 设定图片路径
    private void SetImgPath(int Seleted){
        imgPath = "image\\";
        if(Seleted == GIRL){
            imgPath += "girl\\girl" + rand.nextInt(1,14) + "\\";
            CurX = 3;
            CurY = 3;
            Step = 0; // 步数重置
            AllImgButton = false;
            initData();
            initImg();
            //System.out.println(imgPath);
        }else if(Seleted == ANIMAL){
            imgPath += "animal\\animal" + rand.nextInt(1,9) + "\\";
            CurX = 3;
            CurY = 3;
            Step = 0; // 步数重置
            AllImgButton = false;
            initData();
            initImg();
            //System.out.println(imgPath);
        }else if(Seleted == SPORT){
            imgPath += "sport\\sport" + rand.nextInt(1,11) + "\\";
            CurX = 3;
            CurY = 3;
            Step = 0; // 步数重置
            AllImgButton = false;
            initData();
            initImg();
            //System.out.println(imgPath);
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // Unimplemented method
    }

    @Override // 上 38  下  40  左  37  右  39
    public void keyPressed(KeyEvent e) {
        // System.out.println(e.getKeyCode() + "按下了");
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(AllImgButton) return; // 如果此时是显示完整图片的状态 则不允许移动图片
        if(e.getKeyCode() == 37){
            if(CurY < 3){
                int temp = arr[CurX][CurY + 1];
                arr[CurX][CurY + 1] = arr[CurX][CurY];
                arr[CurX][CurY] = temp;
                CurY++;
                Step++; // 步数增加
                initImg();
            }
        }else if(e.getKeyCode() == 38){
            if(CurX < 3){
                int temp = arr[CurX + 1][CurY];
                arr[CurX + 1][CurY] = arr[CurX][CurY];
                arr[CurX][CurY] = temp;
                CurX++;
                Step++; // 步数增加
                initImg();
            }
        }else if(e.getKeyCode() == 39){
            if(CurY > 0){
                int temp = arr[CurX][CurY - 1];
                arr[CurX][CurY - 1] = arr[CurX][CurY];
                arr[CurX][CurY] = temp;
                CurY--;
                Step++; // 步数增加
                initImg();
            }
        }else if(e.getKeyCode() == 40){
            if(CurX > 0){
                int temp = arr[CurX - 1][CurY];
                arr[CurX - 1][CurY] = arr[CurX][CurY];
                arr[CurX][CurY] = temp;
                CurX--;
                Step++; // 步数增加
                initImg();
            }
        }else if(e.getKeyCode() == 'W'){ // 按W赢得游戏
            arr = new int[][]{
                    {1,2,3,4},
                    {5,6,7,8},
                    {9,10,11,12},
                    {13,14,15,0},
            };
            initImg();
            CurX = 3;
            CurY = 3;
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        // Unimplemented method
    }

    @Override
    public void mousePressed(MouseEvent e) {
        if(AllImgButton) return; // 如果此时是显示完整图片的状态 则不允许移动图片
        GetMousePosition(e);
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if (AllImgButton) return; // 完整图片状态下禁用操作
        if (e.getButton() == MouseEvent.BUTTON1
                && e.getX() >= 90 && e.getX() <= 510
                && e.getY() >= 182 && e.getY() <= 602) {

            // 交换前的两个位置：按下位置 (tempX, tempY) 和释放位置 (CurMouseX, CurMouseY)
            int tempX = CurMouseX; // 按下位置X
            int tempY = CurMouseY; // 按下位置Y
            int temp = arr[tempX][tempY];

            // 获取释放时的坐标（二次点击位置）
            GetMousePosition(e);
            int releaseX = CurMouseX; // 释放位置X
            int releaseY = CurMouseY; // 释放位置Y

            // 交换两个位置的图片值
            arr[tempX][tempY] = arr[releaseX][releaseY];
            arr[releaseX][releaseY] = temp;

            // 关键：仅当交换涉及空白格时更新CurX/CurY
            if (temp == 0) {
                // 按下位置是空白格 → 空白格移动到释放位置
                CurX = releaseX;
                CurY = releaseY;
            } else if (arr[tempX][tempY] == 0) {
                // 释放位置是空白格 → 空白格移动到按下位置
                CurX = tempX;
                CurY = tempY;
            }

            Step++; // 步数增加

            initImg(); // 刷新界面
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        //Unimplemented method
    }

    @Override
    public void mouseExited(MouseEvent e) {
        //Unimplemented method
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals("完整图片")){
            if(!AllImgButton) {
                this.getContentPane().removeAll(); // 移除所有组件
                ImageIcon AllImg = new ImageIcon(imgPath + "all.jpg"); // 加载完整图片
                JLabel AllImgLabel = new JLabel(AllImg); // 创建标签
                AllImgLabel.setBounds(84, 130, AllImg.getIconWidth(), AllImg.getIconHeight()); // 设置标签位置和大小
                // 给图片增加边框
                AllImgLabel.setBorder(new BevelBorder(BevelBorder.RAISED)); // 斜面边框（边框分为好多种 需要用时再查API文档）
                // BevelBorder.RAISED == 0  看起来让图片凸起来
                // BevelBorder.LOWERED == 1  看起来像让图片凹下去
                this.getContentPane().add(AllImgLabel);  // 添加标签到内容窗格

                // 加载步数
                JLabel StepLabel = new JLabel("步数:" + Step);
                StepLabel.setBounds(50, 30, 100, 20);
                this.getContentPane().add(StepLabel);

                // 创建背景图片
                ImageIcon backGround = new ImageIcon("image\\background.png");
                JLabel backGroundLabel = new JLabel(backGround);
                backGroundLabel.setBounds(39, 35, backGround.getIconWidth(), backGround.getIconHeight());
                this.getContentPane().add(backGroundLabel);

                // 重新设置按钮
                setButton();

                this.getContentPane().repaint(); // 刷新

                // 更新状态
                AllImgButton = true;
            }else{
                // 恢复初始状态
                initImg();
                AllImgButton = false;
            }
        }else if(e.getSource() == ReplayItem){ // e.getSource() 获取事件源 (ReplayItem 是JMenuItem对象 所以可以直接用getSource()方法获取事件源)
            // 重新游戏

            Step = 0; // 步数设定为 0（必须先清零 再initImg）

            // 重新生成数据
            initData();

            // 重新加载图片
            initImg();

            // 初始化白板位置
            CurX = 3;
            CurY = 3;

            // 设置状态
            AllImgButton = false;

        }else if(e.getSource() == ReLoginItem){ // 重新登陆
            // 隐藏当前窗口
            this.setVisible(false);

            // 打开登录界面
            new LoginJFrame();

        }else if(e.getSource() == CloseItem){ // 关闭游戏
            // 退出程序(结束虚拟机)
            System.exit(0);
        }else if(e.getSource() == GameDeveloper){ // 游戏作者
            // 创建一个弹框对象
            JDialog jD = new JDialog();

            // 设置弹框的大小
            jD.setSize(680,756);

            // 创建一个管理图片的容器对象
            JLabel jLabel = new JLabel(new ImageIcon("image\\GameDeveloper.jpg"));

            // 设置JLabel容器再弹框中的位置和大小
            jLabel.setBounds(0,0,680,756);

            // 把JLabel容器添加到弹框中
            jD.getContentPane().add(jLabel);

            // 让弹窗置顶
            jD.setAlwaysOnTop(true);

            // 让弹窗居中
            jD.setLocationRelativeTo(null);

            // 弹窗不关闭 则无法操作下面的界面
            jD.setModal(true);

            // 关闭弹窗时销毁弹窗(如果此时它是最后一个界面 则结束虚拟机)
            jD.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

            // 让弹窗显示出来
            jD.setVisible(true);

        }else if(e.getSource() == Buy){ // 氪金入口
            // 创建一个弹框对象
            JDialog jD = new JDialog();

            // 设置弹窗大小
            jD.setSize(649,770);

            // 创建JLable
            JLabel jLabel = new JLabel(new ImageIcon("image\\Money.jpg"));

            // 设置JLable在弹框中的位置和大小
            jLabel.setBounds(0,0,649,770);

            // 添加到弹框中
            jD.getContentPane().add(jLabel);

            // 让弹窗置顶
            jD.setAlwaysOnTop(true);

            // 让弹窗居中
            jD.setLocationRelativeTo(null);

            // 弹窗不关闭 则无法操作下面的界面
            jD.setModal(true);

            // 关闭弹窗时销毁弹窗(如果此时它是最后一个界面 则结束虚拟机)
            jD.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

            // 让弹窗显示出来
            jD.setVisible(true);
        }else if(e.getSource() == Girl){
            // 更换图片
            SetImgPath(GIRL);
            //System.out.println("美女");

        }else if(e.getSource() == Animal){
            // 更换图片
            SetImgPath(ANIMAL);
            //System.out.println("动物");

        }else if(e.getSource() == Sport){
            // 更换图片
            SetImgPath(SPORT);
            //System.out.println("运动");

        }
    }
}
