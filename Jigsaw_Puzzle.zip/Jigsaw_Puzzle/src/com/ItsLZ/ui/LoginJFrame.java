package com.ItsLZ.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Random;

public class LoginJFrame extends JFrame implements ActionListener, MouseListener {
    // JFrame是个JavaBeam类 表示界面 窗体
    // LoginJFrame表示登陆界面

    // 全局变量
    private final String Path = "image\\login\\"; // 路径
    private String IdentifyCode; // 验证码字符串
    private JTextField usernameTextField = new JTextField(); // 用户名输入框
    private JPasswordField passwordField = new JPasswordField(); // 密码输入框
    JTextField IdentifyCodeTextField = new JTextField(); // 验证码输入框
    JLabel RightCode = new JLabel(); // 用JLabel来管理验证码字符串
    JButton LoginButton = new JButton();
    JButton RegisterButton = new JButton();

    public LoginJFrame() { // 构造方法
        // 初始化登陆界面
        initLoginFrame();

        // 初始化图片
        initView();

        // 显示界面
        this.setVisible(true);
    }

    private void initLoginFrame() {
        // 设置界面的宽高
        this.setSize(486,430); // 因为这个LoginJFrame是JFrame的子类，所以可以直接用this.setSize()
        // 居中界面
        this.setLocationRelativeTo(null);
        // 设置标题
        this.setTitle("登陆界面");
        // 关闭窗口时退出程序
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // 取消默认的居中方式
        this.setLocationRelativeTo(null);
        // 禁用布局管理器
        this.setLayout(null);
        // 设置界面置顶
        this.setAlwaysOnTop(true);

    }

    private void initView(){

        JLabel UserNamelabel = new JLabel(new ImageIcon(Path + "username.png"));
        JLabel Passwordlabel = new JLabel(new ImageIcon(Path + "password.png"));
        JLabel Identifylabel = new JLabel(new ImageIcon(Path + "IdentifyCode.png"));
        JLabel BackGroundlabel = new JLabel(new ImageIcon(Path + "background.png" ));

        UserNamelabel.setBounds(-100, -70, getWidth(), getHeight());
        Passwordlabel.setBounds(-92, -10, getWidth(), getHeight());
        Identifylabel.setBounds(-100, 50, getWidth(), getHeight());
        BackGroundlabel.setBounds(-7, -16, getWidth(), getHeight());

        // 添加用户名输入框
        // JTextField usernameTextField = new JTextField(); // 显示输入是输入的字符
        usernameTextField.setBounds(190,131 , 200, 30);
        this.getContentPane().add(usernameTextField);

        // 添加密码输入框
        // JPasswordField passwordField = new JPasswordField(); // 显示输入是 ***
        passwordField.setBounds(190, 191, 200, 30);
        this.getContentPane().add(passwordField);

        // 添加验证码输入框
        // JTextField IdentifyCodeTextField = new JTextField();
        IdentifyCodeTextField.setBounds(190, 251, 100, 30);
        this.getContentPane().add(IdentifyCodeTextField);

        // 添加验证码提示
        IdentifyCode = GetIdentifyCode(); // 返回一个验证码
        // 被注释的已经被我放全局了
        //JLabel RightCode = new JLabel(); // 用JLabel来管理字符串
        RightCode.setText(IdentifyCode); // 设置JLabel的内容
        RightCode.setBounds(300, 251, 100, 30);

        this.getContentPane().add(RightCode);


        // 添加更换验证码的按钮
        JButton ChangeButton = new JButton("换一个");
        ChangeButton.setActionCommand("Change"); //和ActionListener中的e.getActionCommand().equal()有关
        ChangeButton.setBounds(350, 251, 75, 30);
        ChangeButton.addActionListener(this); // 添加ActionListener
        ChangeButton.setFocusable(false);
        this.getContentPane().add(ChangeButton);

        // 给登录按钮添加组件
        // JButton LoginButton = new JButton();
        LoginButton.setActionCommand("Login"); //和ActionListener中的e.getActionCommand().equal()有关
        LoginButton.setIcon(new ImageIcon(Path + "Login1.png")); // 相当于是给按钮的外观变成一个图片了
        LoginButton.setBounds(120,305, 128, 47);
        LoginButton.setBorderPainted(false); // 去除按钮的边框
        LoginButton.setContentAreaFilled(false); // 去除按钮的背景
        // LoginButton.setFocusPainted(false); // 去除按钮焦点边框
        LoginButton.addActionListener(this);
        LoginButton.addMouseListener(this);
        this.getContentPane().add(LoginButton);

        // 给注册按钮添加组件
        // JButton RegisterButton = new JButton();
        RegisterButton.setActionCommand("Register"); //和ActionListener中的e.getActionCommand().equal()有关
        RegisterButton.setIcon(new ImageIcon(Path + "Register1.png")); // 相当于是给按钮的外观变成一个图片了
        RegisterButton.setBounds(270,305, 128, 47);
        RegisterButton.setBorderPainted(false); // 去除按钮的边框
        RegisterButton.setContentAreaFilled(false); // 去除按钮的背景
        // RegisterButton.setFocusPainted(false); // 去除按钮焦点边框
        RegisterButton.addActionListener(this);
        RegisterButton.addMouseListener(this);
        this.getContentPane().add(RegisterButton);

        this.getContentPane().add(UserNamelabel);
        this.getContentPane().add(Passwordlabel);
        this.getContentPane().add(Identifylabel);
        this.getContentPane().add(BackGroundlabel);

    }

    // 获取一个5位的验证码
    private String GetIdentifyCode() {
        // 定义验证码字符集（排除容易混淆的字符）
        String characters = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
        Random random = new Random();
        StringBuilder code = new StringBuilder();

        for (int i = 0; i < 5; i++) {
            // 从字符集中随机选取一个字符
            int index = random.nextInt(characters.length());
            code.append(characters.charAt(index));
        }

        return code.toString();
    }

    public static void ShowJDialog(String Content){
        // 创建弹窗对象
        JDialog jD = new JDialog();
        // 设置弹窗的大小
        jD.setSize(200,150);
        // 让弹窗置顶
        jD.setAlwaysOnTop(true);
        // 居中弹窗
        jD.setLocationRelativeTo(null);
        // 弹窗不关闭则无法操作下面界面
        jD.setModal(true);
        // 使用布局管理器（确保文字居中）
        jD.setLayout(new BorderLayout());
        // 创建JLabel对象管理文字并添加到弹窗
        JLabel label = new JLabel(Content);
        // label.setBounds(200, 150, jD.getWidth(), jD.getHeight());
        // 设置文字居中（水平居中）
        label.setHorizontalAlignment(SwingConstants.CENTER);
        // 设置文字居中（垂直居中）
        label.setVerticalAlignment(SwingConstants.CENTER);
        // 设置字体大小 - 核心代码
        Font font = new Font("Microsoft YaHei", Font.PLAIN, 14); // 创建新字体
        label.setFont(font); // 应用新字体
        // 添加到JD中
        jD.add(label);
        // 显示弹窗
        jD.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getActionCommand().equals("Change")){
           IdentifyCode = GetIdentifyCode();
           RightCode.setText(IdentifyCode);
           this.getContentPane().repaint();
       }else if(e.getActionCommand().equals("Login")){
           String username = usernameTextField.getText();
           String password = new String(passwordField.getPassword()); // passwordField.getPassword()返回的是char[]
           String indentifyCode = IdentifyCodeTextField.getText();

           for(RegisterJFrame.User X : RegisterJFrame.users){
               if(X.Username.equals(username) && X.UserPassword.equals(password) && indentifyCode.equals(IdentifyCode)){
                   ShowJDialog("登录成功");
                   new GameJFrame(); // 创建开始游戏的对象
                   this.setVisible(false); // 关闭页面
                   return;
               }
           }
           ShowJDialog("登录失败");
       }else if(e.getActionCommand().equals("Register")){
            new RegisterJFrame();
            this.setVisible(false); // 关闭页面
       }
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        if(e.getSource() == RegisterButton){
            RegisterButton.setIcon(new ImageIcon(Path + "Register2.png"));

        }else if(e.getSource() == LoginButton){
            LoginButton.setIcon(new ImageIcon(Path + "Login2.png"));
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        if(e.getSource() == RegisterButton){
            RegisterButton.setIcon(new ImageIcon(Path + "Register1.png"));
        }else if(e.getSource() == LoginButton){
            LoginButton.setIcon(new ImageIcon(Path + "Login1.png"));
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
