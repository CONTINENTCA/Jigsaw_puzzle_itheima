import com.ItsLZ.ui.StartGame;

public class Application {
    public static void main(String[] args) {
        // 如果想开启一个界面 就创建谁的对象就可以(创建对象时自动调用它的构造方法(加载界面))
        new StartGame();
    }
}
